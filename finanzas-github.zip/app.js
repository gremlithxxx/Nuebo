const App=(()=>{
const KEY='finanzas_v1';
const CATS=['Comida','Moda y ropa','Electrónica y tecnología','Cuidado personal y belleza','Cuidado del hogar','Mascotas','Salud y bienestar','Pasatiempos','Servicios'];
const base={nombre:'Nombre',ingreso:0,moneda:'$',limite:0,extra:[],compras:[],metas:[],notifs:[]};
let s;
try{s={...base,...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(e){s={...base}}
const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(s))}catch(e){}};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,6);
const money=n=>s.moneda+Number(n||0).toLocaleString('es-MX',{minimumFractionDigits:2,maximumFractionDigits:2});
const gastado=()=>s.compras.reduce((a,c)=>a+c.monto,0);
const saldo=()=>s.ingreso-gastado();
const cats=()=>[...CATS,...s.extra];
const esc=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fecha=iso=>new Date(iso).toLocaleDateString('es-MX',{day:'numeric',month:'short'});
const notify=t=>{s.notifs.unshift({id:uid(),txt:t,fecha:new Date().toISOString(),leida:false});save()};
const $=(q,r=document)=>r.querySelector(q);
function salud(gasto=gastado()){
  if(s.ingreso<=0)return{score:null,label:'Sin datos',cls:'',ratio:0};
  const ratio=gasto/s.ingreso;
  let score=100-ratio*100+(s.metas.some(m=>m.ahorrado>0)?10:0);
  score=Math.round(Math.max(0,Math.min(100,score)));
  return{score,ratio,...(score>=70?{label:'Saludable',cls:'ok'}:score>=40?{label:'Estable',cls:'warn'}:{label:'En riesgo',cls:'bad'})};
}
function toast(t){const e=document.createElement('div');e.className='toast';e.textContent=t;document.body.append(e);setTimeout(()=>e.remove(),2200)}
function sheet(html){
  const o=document.createElement('div');o.className='ov';
  o.innerHTML='<div class="sheet" role="dialog" aria-modal="true">'+html+'</div>';
  const close=()=>o.remove();
  o.addEventListener('click',e=>{if(e.target===o)close()});
  document.addEventListener('keydown',function k(e){if(e.key==='Escape'){close();document.removeEventListener('keydown',k)}});
  document.body.append(o);return{el:o,close};
}
function reset(){s.compras=[];save()}
function wipe(){s={...base};save()}
return{s:()=>s,set:o=>{Object.assign(s,o);save()},save,uid,money,gastado,saldo,cats,esc,fecha,notify,salud,toast,sheet,$,reset,wipe,CATS}
})();
